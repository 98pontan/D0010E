public class Main {
   /**
    * Creates an object of the class driver and then calls the run method in the driver object
    * @author Pontus Eriksson Jirbratt, ponjir-7
    * @param args
    */
   public static void main(String[] args) {
      Driver driver = new Driver();
      driver.run();

   }
}